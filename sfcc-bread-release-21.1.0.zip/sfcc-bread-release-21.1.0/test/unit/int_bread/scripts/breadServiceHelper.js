'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru().noPreserveCache();
var Site = require('../../../mocks/dw/system/Site');
var URLUtils = require('../../../mocks/dw/web/URLUtils');
var Transaction = require('../../../mocks/dw/system/Transaction');
var Order = require('../../../mocks/dw/order/Order');
var serviceInit = require('../../../mocks/scripts/service/serviceInit');
var breadData = proxyquire('../../../../cartridges/int_bread/cartridge/scripts/lib/breadData', {
    'dw/system/Site'  : Site,
    'dw/web/URLUtils' : URLUtils
});

var breadServiceHelper = proxyquire('../../../../cartridges/int_bread/cartridge/scripts/service/breadServiceHelper', {
    '*/cartridge/scripts/lib/breadData.js' : breadData,
    '*/cartridge/scripts/service/breadInit.js' : serviceInit,
    'dw/system/Transaction' : Transaction,
    'dw/order/Order' : Order
});


describe('breadServiceHelper - Test helper util, used for requests', function () {

    describe('getTransaction(), function to make a call to service', function () {
        it('Check if response object is as expected', function () {
            let responseOk = {
                "status":"PENDING"
            }
            let order = {
                custom: {
                    bread_status: ''
                }
            }
            assert.deepEqual(breadServiceHelper.getTransaction('123', order), responseOk);
        });
    });

    describe('actionTransaction(), function to make a call to service', function () {
        it('Check if response object is as expected', function () {
            let responseOk = {
                "status":"SETTLED"
            }
            let order = {
                custom: {
                    bread_status: '',
                    bread_token: '123',
                    orderNo: '123'
                }
            }
            assert.deepEqual(breadServiceHelper.actionTransaction(order, "authorize"), responseOk);
        });
    });

});