var Site = require('../../../mocks/dw/system/Site');
var currentSite = Site.getCurrent();

var serviceinit = function () {};

function serviceV2Response() {
    var urlPathSplitted = this.url.split('/');
    var action = urlPathSplitted[urlPathSplitted.length - 1];
    var result = {
        ok: true,
        object: {
            text: ''
        },
        status: 0,
        error_message: 'OK'
    };

    switch (action) {
        case 'authenticate':
            result.object.text = JSON.stringify({ token: 'token', tokenExpiresAt: '2030-04-21T08:34:10.908505125Z' });
            break;
        case 'authorize':
            result.object.text = JSON.stringify({ status: 'AUTHORIZED' });
            break;
        case 'settle':
            result.object.text = JSON.stringify({ status: 'SETTLED' });
            break;

        default: result.object.text = JSON.stringify({ status: 'PENDING' });
    }

    return result;
}

function serviceResponse(attr) {
    var action = null;
    var responseStatus = 'PENDING';
    if (attr) {
        action = JSON.parse(attr).type;
        switch (action) {
            case 'authorize':
                responseStatus = 'AUTHORIZED';
                break;
            case 'settle':
                responseStatus = 'SETTLED';
                break;

            default: responseStatus = 'PENDING';
        }
    }
    var result = {
        ok: true,
        object: {
            text: '{"status":"' + responseStatus + '"}'
        },
        status: 0,
        error_message: 'OK'
    };

    return result;
}

serviceinit.prototype.url = null;
serviceinit.prototype.header = [];
serviceinit.prototype.requestMethod = null;
serviceinit.prototype.configuration = { credential: {} };
serviceinit.prototype.setRequestMethod = function (requestMethod) { this.requestMethod = requestMethod; };
serviceinit.prototype.setURL = function (url) { this.url = url; };
serviceinit.prototype.getURL = function () { return this.url; };
serviceinit.prototype.getClient = function () {
    return {
        getResponseHeader: function () {
            return new String('application/json');
        }
    };
};
serviceinit.prototype.call = function (attr) {
    return currentSite.customPreferences.bread_useNewBreadAPI
        ? serviceV2Response.call(this)
        : serviceResponse(attr);
};
serviceinit.prototype.addHeader = function (type, value) {
    this.header.push({
        type: type,
        value: value
    });
};
serviceinit.prototype.setThrowOnError = function () {
    var serviceURL = this.url;
    var requestMethod = this.requestMethod;
    return {
        call: function (text) {
            return {
                ok: true,
                object: serviceResponse(text, serviceURL),
                requestParam: {
                    requestMethod: serviceURL,
                    url: requestMethod
                }
            };
        }
    };
};

module.exports = new serviceinit();
