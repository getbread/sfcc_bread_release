module.exports = {
    items: '[{"name":"Navy Single Pleat Wool Suit","price":29999,"sku":"750518548296M","imageUrl":"http://astound32-alliance-prtnr-eu04-dw.demandware.net/on/demandware.static/-/Sites-apparel-m-catalog/default/dwa48ded0a/images/large/PG.52002RUBN4Q.NAVYWL.PZ.jpg","detailUrl":"https://astound32-alliance-prtnr-eu04-dw.demandware.net/s/Bread_SFRA/navy-single-pleat-wool-suit/750518548296M.html?lang=en_US","quantity":1}]',
    billingContact: '{"fullName":"Wendy Smith","address":"1000 Ainsworth Dr","zip":"86305","city":"Prescott","state":"AZ","phone":"3333333333","email":"test@test.com"}',
    customTotal: '32548',
    adjustedCustomTotal: '32548',
    customTotalTax: '1550',
    shippingContact: '{"fullName":"Wendy Smith","address":"1000 Ainsworth Dr","zip":"86305","city":"Prescott","state":"AZ","phone":"3333333333"}',
    shippingOptions: '[{"typeId":"001","cost":999,"type":"Ground"}]',
    shippingCost: '1049',
    shippingMethodCode: 'Ground',
    requireShippingContact: true
};

