var Money = require('../../dw/value/Money');
var imageUrl = 'http://astound32-alliance-prtnr-eu04-dw.demandware.net/on/demandware.static/-/Sites-apparel-m-catalog/default/dwa48ded0a/images/large/PG.52002RUBN4Q.NAVYWL.PZ.jpg';

var Product = function () {
    var that = this;
    this.price = new Money(299.99, 'USD'),
    this.adjustedPrice = new Money(15, 'USD'),
    this.productID = '750518548296M',
    this.productName = 'Navy Single Pleat Wool Suit',
    this.adjustedTax = new Money(2, 'USD'),
    this.taxRate = 2,
    this.basePrice = new Money(315, 'USD'),
    this.taxClassID = 'TaxClassID',
    this.quantity = {
        unit: '',
        value: 1,
        getUnit: function () { return this.unit; }
    },
    this.getPrice = function () { return this.price; },
    this.getAdjustedPrice = function () { return this.adjustedPrice; },
    this.getImage = function () {
        return {
            getHttpURL: function () {
                return {
                    toString: function () {
                        return imageUrl;
                    }
                };
            }
        };
    },
    this.getProratedPrice = function () { return this.price; },
    this.getID = function () { return this.productID; },
    this.getName = function () { return this.productName; },
    this.getQuantityValue = function () { return this.quantity.value; },
    this.getAdjustedTax = function () { return this.adjustedTax; },
    this.getTaxRate = function () { return this.taxRate; },
    this.getQuantity = function () { return this.quantity; },
    this.getProduct = function () { return this.product; },
    this.getBasePrice = function () { return this.basePrice; },
    this.getTaxClassID = function () { return this.taxClassID; };
    this.getPriceModel = function () {
        return {
            getMinPrice: function () {
                return that.price;
            }
        };
    };
};

module.exports = Product;
