var _super = require('../../dw/order/LineItemCtnr');
var Money = require('../../dw/value/Money');
var Collection = require('../../dw/util/Collection');

var Product = function () {
    var that = this;
    this.price = new Money(299.99, 'USD'),
    this.adjustedPrice = new Money(15, 'USD'),
    this.adjustedNetPrice = new Money(13, 'USD'),
    this.productID = '750518548296M',
    this.productName = 'Navy Single Pleat Wool Suit',
    this.adjustedTax = new Money(2, 'USD'),
    this.taxRate = 2,
    this.basePrice = new Money(315, 'USD'),
    this.taxClassID = 'TaxClassID',
    this.quantity = {
        unit: '',
        value: 1,
        getUnit: function () { return this.unit; }
    },
    this.getPrice = function () { return this.price; },
    this.getAdjustedPrice = function () { return this.adjustedPrice; },
    this.getImage = function () {
        return {
            getHttpURL: function () {
                return {
                    toString: function () {
                        return imageUrl;
                    }
                };
            }
        };
    },
    this.getProratedPrice = function () { return this.price; },
    this.getProductID = function () { return this.productID; },
    this.getProductName = function () { return this.productName; },
    this.getQuantityValue = function () { return this.quantity.value; },
    this.getAdjustedTax = function () { return this.adjustedTax; },
    this.getTaxRate = function () { return this.taxRate; },
    this.getQuantity = function () { return this.quantity; },
    this.getProduct = function () { return this.product; },
    this.getBasePrice = function () { return this.basePrice; },
    this.getTaxClassID = function () { return this.taxClassID; };
};

var product = new Product();
product.getProduct = function () { return product; };


var Basket = function () {};
Basket.prototype = new _super();

var imageUrl = 'http://astound32-alliance-prtnr-eu04-dw.demandware.net/on/demandware.static/-/Sites-apparel-m-catalog/default/dwa48ded0a/images/large/PG.52002RUBN4Q.NAVYWL.PZ.jpg';

Basket.prototype.giftCertificateLineItems = Collection.createFromArray([]);
Basket.prototype.productLineItems = Collection.createFromArray([
    product
]);

Basket.prototype.defaultShipment = {
    shippingAddress: {
        companyName: 'Company Name',
        address1: 'Customer address 1',
        address2: 'Customer address 2',
        city: 'City',
        firstName: 'Customer name',
        lastName: 'Customer surname',
        fullName: 'Customer fullname',
        phone: 'Customer phone',
        stateCode: 'PE',
        postalCode: '01235',
        countryCode: {
            displayValue: 'USA',
            value: 'US',
            valueOf: function () { return this.value; }
        }
    },
    getShippingAddress: function () {
        return this.shippingAddress;
    }
};

Basket.prototype.shipments = [
    {
        shippingAddress: {
            fullName: 'Wendy Smith',
            address1: '1000 Ainsworth Dr',
            postalCode: '86305',
            city: 'Prescott',
            stateCode: 'AZ',
            phone: '3333333333',
            countryCode: {
                displayValue: 'USA',
                value: 'US',
                valueOf: function () { return this.value; }
            }
        },
        shippingMethod: {
            ID: '001',
            displayName: 'Ground'
        }
    }
];

Basket.prototype.shippingTotalGrossPrice = new Money(10.49, 'USD');
Basket.prototype.getShippingTotalPrice = function () {
    return new Money(9.99, 'USD');
};
Basket.prototype.billingAddress = {
    companyName: 'Company Name',
    address1: '1000 Ainsworth Dr',
    address2: 'Customer address 2',
    city: 'Prescott',
    firstName: 'Customer name',
    lastName: 'Customer surname',
    fullName: 'Wendy Smith',
    phone: '3333333333',
    stateCode: 'AZ',
    postalCode: '86305',
    countryCode: {
        displayValue: 'USA',
        value: 'US',
        valueOf: function () { return this.value; }
    }
};

Basket.prototype.getGiftCertificatePaymentInstruments = function () { return []; };
Basket.prototype.UUID = 'order_uuid';
Basket.prototype.customerNo = 'Customer_001';
Basket.prototype.adjustedMerchandizeTotalTax = new Money(20, 'USD');
Basket.prototype.totalTax = new Money(15.50, 'USD');
Basket.prototype.shippingTotalPrice = new Money(30, 'USD');
Basket.prototype.currencyCode = 'USD';
Basket.prototype.totalGrossPrice = new Money(325.48, 'USD');
Basket.prototype.customerEmail = 'test@test.com';

Basket.prototype.getOrderBeingEdited = function () {};
Basket.prototype.getOrderNoBeingEdited = function () {};
Basket.prototype.orderBeingEdited = null;
Basket.prototype.orderNoBeingEdited = null;

Basket.prototype.adjustedMerchandizeTotalPrice = new Money(125, 'USD');
Basket.prototype.getAdjustedMerchandizeTotalPrice = function () {
    return this.adjustedMerchandizeTotalPrice;
};
Basket.prototype.adjustedShippingTotalPrice = new Money(25, 'USD');

module.exports = Basket;
