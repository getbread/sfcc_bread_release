/**
 * Create a mock module.superModule
 * @param {Object} mock - mock
 */
function create(mock) {
    module.__proto__.superModule = mock;
}

/**
 * Delete the mock module.superModule
 */
function remove() {
    delete module.__proto__.superModule;
}

module.exports = {
    create: create,
    remove: remove
};
