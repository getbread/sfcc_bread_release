
/* API Includes */
var Transaction = require('dw/system/Transaction');
var Cart = require('*/cartridge/scripts/models/CartModel');
var PaymentMgr = require('dw/order/PaymentMgr');
var breadHelper = require('*/cartridge/scripts/lib/breadHelper');
/**
 * Handles a payment using  BREAD. The payment is handled by using the BREAD processor
 * @param {Object} args - object of arguments to work with
 * @return {Object} - error or success
 */
function Handle(args) {
    try {
        var cart = Cart.get(args.Basket);
        Transaction.wrap(function () {
            cart.removeExistingPaymentInstruments('BREAD');
            cart.createPaymentInstrument('BREAD', cart.getNonGiftCertificateAmount());
        });
    } catch (e) {
        return { error: true };
    }

    return { success: true };
}

/**
 * Authorizes a payment using  BREAD. The payment is authorized by using the BREAD processor
 * @param {Object} args - object of arguments to work with
 * @return {Object} - error or authorized
 */
function Authorize(args) {
    var token = request.httpParameterMap.token
        ? request.httpParameterMap.token.value
        : false;

    var paymentInstrument = args.PaymentInstrument;
    var paymentProcessor = PaymentMgr.getPaymentMethod(paymentInstrument.getPaymentMethod()).getPaymentProcessor();
    var breadServiceHelper = require('*/cartridge/scripts/lib/breadData.js').getBreadServiceHelper();
    var orderTotal = breadHelper.priceToInteger(breadHelper.getNonGiftCertificateOrderAmount(args.Order));

    if (token) {
        var transaction = breadServiceHelper.getTransaction(token);
        var txnTotal = transaction.total || transaction.totalAmount.value;
        Transaction.wrap(function () {
            args.Order.custom.bread_token = token; // eslint-disable-line no-param-reassign
            paymentInstrument.paymentTransaction.paymentProcessor = paymentProcessor;
        });
        // if basket was changed during BREAD checkout we will not place order
        if (txnTotal !== orderTotal) {
            breadServiceHelper.actionTransaction(args.Order, 'cancel', orderTotal);
            return { error: true };
        }
    } else {
        return { error: true };
    }
    breadServiceHelper.actionTransaction(args.Order, 'authorize', orderTotal);
    return { authorized: true };
}

exports.Handle = Handle;
exports.Authorize = Authorize;

