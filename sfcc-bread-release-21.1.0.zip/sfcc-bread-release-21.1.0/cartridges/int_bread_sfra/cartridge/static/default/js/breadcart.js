$('body').on('cart:update promotion:success cart:shippingMethodSelected', function () {
    var url = $('#js_breadcart').data('action');
    if (url) {
        $.ajax({
            url: url,
            success: function (data) {
                $('#js_breadcart').replaceWith(data);
            }
        });
    }
});