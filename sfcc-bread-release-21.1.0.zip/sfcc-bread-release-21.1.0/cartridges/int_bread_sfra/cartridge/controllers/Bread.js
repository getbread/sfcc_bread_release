'use strict';
var server = require('server');
// just to have ajax access to button
server.get('Button', function (req, res, next) {
    var breadData = require('*/cartridge/scripts/lib/breadData.js');
    var usingNewApi = breadData.useNewBreadApi();
    var buttonLocation = req.querystring.location;
    if (!buttonLocation) {
        var checkoutButtonTemplate = usingNewApi ? 'bread/buttonOnCheckoutV2' : 'bread/buttonOnCheckout';
        res.render(checkoutButtonTemplate);
        return next();
    }
    if (buttonLocation === 'cart') {
        var cartButtonTemplate = usingNewApi ? 'bread/buttonOnCartV2' : 'bread/buttonOnCart';
        res.render(cartButtonTemplate);
        return next();
    }
    if (buttonLocation === 'pdp') {
        var ProductMgr = require('dw/catalog/ProductMgr');
        var pdpButtonTemplate = usingNewApi ? 'bread/buttonOnPdpV2' : 'bread/buttonOnPdp';
        var viewData = {
            product: {}
        };
        if (req.querystring.pids) {
            var pidsArray = JSON.parse(req.querystring.pids);
            viewData.product.productType = 'set';
            viewData.product.individualProducts = pidsArray.map(function (productID) {
                return ProductMgr.getProduct(productID);
            });
        } else {
            viewData.product = ProductMgr.getProduct(req.querystring.pid);
        }
        res.render(pdpButtonTemplate, viewData);
        return next();
    }

    return next();
});

module.exports = server.exports();
