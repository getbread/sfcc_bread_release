/**
 *     job script for cancel transactions in BREAD
 */

var OrderMgr = require('dw/order/OrderMgr');
var Order = require('dw/order/Order');
var Transaction = require('dw/system/Transaction');

// Local includes
var data = require('*/cartridge/scripts/lib/breadData.js');
var breadHelper = require('*/cartridge/scripts/lib/breadHelper');
/**
 * Cancel orders selected by custom attribute bread_isExported
 * @returns {boolean} - job response
 */
function cancelOrders() {
    var service = data.getBreadServiceHelper();
    if (data.isBreadEnabled()) {
        var canceledOrder = OrderMgr.searchOrders('status = {0} AND order.custom.bread_token != NULL AND order.custom.bread_isExported = {1}', 'creationDate', Order.ORDER_STATUS_CANCELLED, null);
        while (canceledOrder.hasNext()) {
            var order = canceledOrder.next();
            var orderTotal = breadHelper.priceToInteger(breadHelper.getNonGiftCertificateOrderAmount(order));
            var status = service.actionTransaction(order, 'cancel', orderTotal);
            if (!status.error) {
                Transaction.wrap(function () { // eslint-disable-line no-loop-func
                    order.custom.bread_isExported = true;
                });
            }
        }
        canceledOrder.close();
    }
    return true;
}

module.exports.execute = cancelOrders;
