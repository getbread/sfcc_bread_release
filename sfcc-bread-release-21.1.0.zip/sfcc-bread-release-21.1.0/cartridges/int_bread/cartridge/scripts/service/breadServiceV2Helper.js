// module for transactions with bread new service api
var Transaction = require('dw/system/Transaction');
var Order = require('dw/order/Order');
var breadData = require('*/cartridge/scripts/lib/breadData.js');

var Calls = function () {
    var service = require('*/cartridge/scripts/service/breadInit.js');
    var apiUrl = breadData.getNewServerApiUrl();
    var authUrl = breadData.getAuthUrl();
    var that = this;
    // retrieve
    that.getTransaction = function (trId, order) {
        var getTokenResult = that.getToken();
        if (!getTokenResult.token) {
            return getTokenResult;
        }
        service.setRequestMethod('GET');
        service.setURL(apiUrl + '/api/transaction/' + trId);
        service.addHeader('Authorization', 'Bearer ' + getTokenResult.token);
        var response = service.call();
        var object = false;
        if (response.ok && !response.object.errorText) {
            try {
                object = JSON.parse(response.object.text);
                if (order && object.status) {
                    Transaction.wrap(function () {
                        order.custom.bread_status = object.status; // eslint-disable-line no-param-reassign
                    });
                }
            } catch (e) {
                object = { error: true, status: e.message };
            }
        }
        return object;
    };
    // cancel, settle, refund and authorize
    that.actionTransaction = function (order, action, amountValue) {
        var getTokenResult = that.getToken();
        if (!getTokenResult.token) {
            return getTokenResult;
        }
        var param = {
            amount: {
                currency: order.currencyCode,
                value: Number(amountValue)
            }
        };
        service.setRequestMethod('POST');
        service.setURL(apiUrl + '/api/transaction/' + order.custom.bread_token + '/' + action);
        service.addHeader('Content-Type', 'application/json');
        service.addHeader('Authorization', 'Bearer ' + getTokenResult.token);

        var response = service.call(JSON.stringify(param));
        var object = false;
        if (response.ok) {
            // try catch error
            try {
                object = JSON.parse(response.object.text);
                Transaction.wrap(function () {
                    if ('status' in object) {
                        order.custom.bread_status = object.status; // eslint-disable-line no-param-reassign
                    }
                    if (action === 'authorize') {
                        order.setPaymentStatus(Order.PAYMENT_STATUS_PAID);
                    }
                });
            } catch (e) {
                object = { error: true, msg: e.message };
            }
        } else {
            object = { error: true, msg: response.errorMessage, param: JSON.stringify(param) };
        }
        // if settle is enabled in site preferences we call transaction again with settle param
        if (action === 'authorize' && breadData.isSettleEnabled()) {
            return that.actionTransaction(order, 'settle', amountValue);
        }
        return object;
    };

    that.getToken = function () {
        if (session.privacy.apiToken && session.privacy.tokenExpiresAt) {
            if (Date.parse(session.privacy.tokenExpiresAt) - Date.now() > 0) {
                return { token: session.privacy.apiToken };
            }
        }
        service.setRequestMethod('POST');
        service.setURL(authUrl);
        service.addHeader('Content-Type', 'application/json');
        var serviceCredentials = service.configuration.credential;
        var param = {
            apiKey: serviceCredentials.user,
            secret: serviceCredentials.password
        };
        var response = service.call(JSON.stringify(param));
        var object;
        if (response.ok) {
            try {
                object = JSON.parse(response.object.text);
                if (object.token && object.tokenExpiresAt) {
                    session.privacy.apiToken = object.token;
                    session.privacy.tokenExpiresAt = object.tokenExpiresAt.replace(/\.(.*?)Z/, '');
                }
            } catch (e) {
                object = { error: true, msg: e.message };
            }
        } else {
            object = { error: true, msg: response.errorMessage };
        }
        return object;
    };
};

module.exports = new Calls();
