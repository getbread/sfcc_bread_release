// module for transactions with bread service api
var Transaction = require('dw/system/Transaction');
var Order = require('dw/order/Order');
var breadData = require('*/cartridge/scripts/lib/breadData.js');

var Calls = function () {
    var service = require('*/cartridge/scripts/service/breadInit.js');
    var apiUrl = breadData.getServerApiUrl();
    var that = this;
    // retrieve
    that.getTransaction = function (trId, order) {
        service.setRequestMethod('GET');
        service.setURL(apiUrl + '/transactions/' + trId);
        var response = service.call();
        var object = false;
        if (response.ok && !response.object.errorText) {
            try {
                object = JSON.parse(response.object.text);
                if (order && object.status) {
                    Transaction.wrap(function () {
                        order.custom.bread_status = object.status; // eslint-disable-line no-param-reassign
                    });
                }
            } catch (e) {
                object = { error: true, status: e.message };
            }
        }
        return object;
    };
    // cancel, settle, refund and authorize
    that.actionTransaction = function (order, action, amount, items) {
        var param = { type: action };
        service.setRequestMethod('POST');
        service.setURL(apiUrl + '/transactions/actions/' + order.custom.bread_token);
        service.addHeader('Content-Type', 'application/json');
        param.merchantOrderId = order.orderNo;
        if (amount) {
            param.amount = Number(amount);
            if (items) {
                param.lineItems = items;
            }
        }
        var response = service.call(JSON.stringify(param));
        var object = false;
        if (response.ok) {
            // try catch error
            try {
                object = JSON.parse(response.object.text);
                Transaction.wrap(function () {
                    if ('status' in object) {
                        order.custom.bread_status = object.status; // eslint-disable-line no-param-reassign
                    }
                    if (action === 'authorize') {
                        order.setPaymentStatus(Order.PAYMENT_STATUS_PAID);
                    }
                });
            } catch (e) {
                object = { error: true, msg: e.message };
            }
        } else {
            object = { error: true, msg: response.errorMessage, param: JSON.stringify(param) };
        }
        // if settle is enabled in site preferences we call transaction again with settle param
        if (action === 'authorize' && breadData.isSettleEnabled()) {
            return that.actionTransaction(order, 'settle');
        }
        return object;
    };
};

module.exports = new Calls();
