'use strict';

require('shelljs/make');
var path = require('path');
var webpack = require('sgmf-scripts').webpack;
var ExtractTextPlugin = require('sgmf-scripts')['extract-text-webpack-plugin'];
var packageName = 'int_bread_sfra';
//var packageName = 'app_storefront_base';

var createJSPath = function () {
    var result = {};
    var jsFiles = ls(`./cartridges/${packageName}/cartridge/client/**/js/*.js`);

    jsFiles.forEach(function (filePath) {
        // var location = path.basename(filePath, '.js');
        var location = path.relative(`./cartridges/${packageName}/cartridge/client`, filePath);
        location = location.substr(0, location.length - 3);
        result[location] = filePath;
    });
    return result;
};

var bootstrapPackages = {
    Alert     : 'exports-loader?Alert!bootstrap/js/src/alert',
    // Button: 'exports-loader?Button!bootstrap/js/src/button',
    Carousel  : 'exports-loader?Carousel!bootstrap/js/src/carousel',
    Collapse  : 'exports-loader?Collapse!bootstrap/js/src/collapse',
    // Dropdown: 'exports-loader?Dropdown!bootstrap/js/src/dropdown',
    Modal     : 'exports-loader?Modal!bootstrap/js/src/modal',
    // Popover: 'exports-loader?Popover!bootstrap/js/src/popover',
    Scrollspy : 'exports-loader?Scrollspy!bootstrap/js/src/scrollspy',
    Tab       : 'exports-loader?Tab!bootstrap/js/src/tab',
    // Tooltip: 'exports-loader?Tooltip!bootstrap/js/src/tooltip',
    Util      : 'exports-loader?Util!bootstrap/js/src/util'
};

module.exports = [{
    mode   : 'production',
    name   : 'js',
    entry  : createJSPath(),
    output : {
        path     : path.resolve(`./cartridges/${packageName}/cartridge/static`),
        filename : '[name].js'
    },
    module: {
        rules: [
            {
                test : /bootstrap(.)*\.js$/,
                use  : {
                    loader  : 'babel-loader',
                    options : {
                        presets        : ['@babel/env'],
                        plugins        : ['@babel/plugin-proposal-object-rest-spread'],
                        cacheDirectory : true
                    }
                }
            }
        ]
    },
    plugins: [new webpack.ProvidePlugin(bootstrapPackages)]
}];
