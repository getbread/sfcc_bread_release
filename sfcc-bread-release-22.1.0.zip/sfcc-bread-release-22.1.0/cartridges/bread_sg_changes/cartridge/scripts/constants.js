/*
 * not part of certification
*/

let constants = {
    storefront_controllers: 'app_storefront_controllers',
    storefront_core: 'app_storefront_core'
};

module.exports = constants;
