'use strict';

let Status = require('dw/system/Status');
let logger = require('dw/system').Logger.getLogger('Bread', '');

/**
 * @returns {dw.system.Status} result status
 */
function execute() {
    let breadJobs = require('int_bread/cartridge/scripts/bread');
    try {
        breadJobs.sync();
        return new Status(Status.OK);
    } catch (e) {
        logger.error(e)
        return new Status(Status.ERROR);
    }
}

exports.execute = execute;