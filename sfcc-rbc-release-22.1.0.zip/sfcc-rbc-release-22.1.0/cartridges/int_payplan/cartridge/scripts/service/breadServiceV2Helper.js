// module for transactions with bread new service api
let Transaction = require('dw/system/Transaction');
let Order = require('dw/order/Order');
let ProductLineItem = require('dw/order/ProductLineItem');
let ShippingLineItem = require('dw/order/ShippingLineItem');
let CacheMgr = require('dw/system/CacheMgr');
let Site = require('dw/system/Site')
let breadData = require('int_payplan/cartridge/scripts/lib/breadData.js');
let logger = require('dw/system').Logger.getLogger('Bread', '');

let Calls = function () {
    let service = require('int_payplan/cartridge/scripts/service/breadInit.js');
    let apiUrl = breadData.getServerApiUrl();
    let authUrl = breadData.getAuthUrl();
    let that = this;
    // retrieve
    that.getTransaction = function (trId, order) {
        let getTokenResult = that.getToken();
        if (!getTokenResult.token) {
            return getTokenResult;
        }
        service.setRequestMethod('GET');
        service.setURL(apiUrl + '/api/transaction/' + trId);
        service.addHeader('Authorization', 'Bearer ' + getTokenResult.token);
        let response = service.call();
        let object = false;
        if (response.ok && !response.object.errorText) {
            try {
                object = JSON.parse(response.object.text);
                if (order && object.status) {
                    Transaction.wrap(function () {
                        order.custom.payplan_status = object.status; // eslint-disable-line no-param-reassign
                    });
                }
            } catch (e) {
                object = { error: true, status: e.message };
            }
        }
        return object;
    };

    // cancel, settle, refund and authorize
    that.actionTransaction = function (order, action, amountValue) {
        let getTokenResult = that.getToken();
        if (!getTokenResult.token) {
            return getTokenResult;
        }
        let param = {
            amount: {
                currency: order.currencyCode,
                value: Number(amountValue)
            }
        };
        service.setRequestMethod('POST');
        service.setURL(apiUrl + '/api/transaction/' + order.custom.payplan_token + '/' + action);
        service.addHeader('Content-Type', 'application/json');
        service.addHeader('Authorization', 'Bearer ' + getTokenResult.token);

        let response = service.call(JSON.stringify(param));
        let object = false;
        if (response.ok) {
            // try catch error
            try {
                object = JSON.parse(response.object.text);
                Transaction.wrap(function () {
                    if ('status' in object) {
                        order.custom.payplan_status = object.status; // eslint-disable-line no-param-reassign
                    }
                    if (action === 'authorize') {
                        order.setPaymentStatus(Order.PAYMENT_STATUS_PAID);
                    }
                });
            } catch (e) {
                object = { error: true, msg: e.message };
            }
        } else {
            object = { error: true, msg: response.errorMessage, param: JSON.stringify(param) };
        }
        // if settle is enabled in site preferences we call transaction again with settle param
        if (action === 'authorize' && breadData.isSettleEnabled()) {
            return that.actionTransaction(order, 'settle', amountValue);
        }
        return object;
    };

    // update shipping info
    that.updateShipping = function (order, shippingRequest) {
        let getTokenResult = that.getToken();
        if (!getTokenResult.token) {
            return getTokenResult;
        }
        service.setRequestMethod('POST');
        service.setURL(apiUrl + '/api/transaction/' + order.custom.payplan_token + '/fulfillment');
        service.addHeader('Content-Type', 'application/json');
        service.addHeader('Authorization', 'Bearer ' + getTokenResult.token);

        let response = service.call(JSON.stringify(shippingRequest));
        let object = {};
        if (response.ok) {
            // try catch error
            try {
                object = JSON.parse(response.object.text);
            } catch (e) {
                object = { error: true, msg: e.message };
            }
        } else {
            object = { error: true, msg: response.errorMessage, request: JSON.stringify(shippingRequest) };
        }
        return object;
    };

    // update order number
    that.updateOrderNumber = function (order) {
        let getTokenResult = that.getToken();
        if (!getTokenResult.token) {
            return getTokenResult;
        }
        service.setRequestMethod('PATCH');
        service.setURL(apiUrl + '/api/transaction/' + order.custom.payplan_token);
        service.addHeader('Content-Type', 'application/json');
        service.addHeader('Authorization', 'Bearer ' + getTokenResult.token);

        let request = {
            externalID: order.orderNo,
        }
        let response = service.call(JSON.stringify(request));
        let object = {};
        if (response.ok) {
            // try catch error
            try {
                object = JSON.parse(response.object.text);
            } catch (e) {
                object = { error: true, msg: e.message };
            }
        } else {
            object = { error: true, msg: response.errorMessage, request: JSON.stringify(request) };
        }
        return object;
    };

    that.recordCheckout = function (order) {
        let merchantInfo = that.merchantInfo();
        let address = order.getBillingAddress()

        let checkout = {
            transactionId: order.custom.payplan_token,
            merchantId: merchantInfo.merchantID,
            storeId: Site.current.name,
            order: {
                items: [],
                currency: order.getCurrencyCode(),
                subTotal: {
                    value: Math.round(order.getMerchandizeTotalPrice().value * 100),
                    currency: order.getCurrencyCode(),
                },
                totalShipping: {
                    value: Math.round(order.shippingTotalPrice.value * 100),
                    currency: order.getCurrencyCode(),
                },
                totalTax: {
                    value: Math.round(order.totalTax.value * 100),
                    currency: order.getCurrencyCode(),
                },
                totalDiscounts: {
                    value: Math.round(0 * 100),
                    currency: order.getCurrencyCode(),
                },
                totalPrice: {
                    value: Math.round(order.totalGrossPrice.value * 100),
                    currency: order.getCurrencyCode(),
                },
            },
            buyer: {
                givenName: address.firstName,
                familyName: address.lastName,
                phone: address.phone,
                email: order.getCustomerEmail(),
                shippingAddress: {
                    address1: address.address1,
                    address2: address.address2,
                    locality: address.city,
                    region: address.stateCode,
                    postalCode: address.postalCode,
                    country: "", // TODO for some reason, address.countryCode is a blank enum...
                }
            },
            test: breadData.getEnvironment() === "sandbox",
            status: "AUTHORIZED",
            orderNumber: order.getOrderNo(),
        };

        let items = order.getAllLineItems()
        for each (product in items) {
            if (product instanceof ProductLineItem) {
                let item =                     {
                    name: product.getProductName(),
                    sku: product.manufacturerSKU,
                    unitPrice: Math.round(product.netPrice * 100),
                    shippingCost: 0,
                    shippingDescription: "",
                    unitTax: Math.round(product.tax.value * 100),
                    brand: "",
                    currency: order.getCurrencyCode(),
                    quantity: product.quantityValue,
                }
                checkout.order.items.push(item)
            }
            if (product instanceof ShippingLineItem) {
                logger.info('SHIPPING LINE ITEM');
            }
        }

        let getTokenResult = that.getToken();
        if (!getTokenResult.token) {
            return getTokenResult;
        }
        service.setRequestMethod('POST');
        service.setURL(apiUrl + '/api/core-plugin-backend/record-checkout');
        service.addHeader('Content-Type', 'application/json');
        service.addHeader('Authorization', 'Bearer ' + getTokenResult.token);

        let response = service.call(JSON.stringify(checkout));
        let object = {};
        if (response.ok) {
            // try catch error
            try {
                object = JSON.parse(response.object.text);
            } catch (e) {
                object = { error: true, msg: e.message };
            }
        } else {
            object = { error: true, msg: response.errorMessage, request: JSON.stringify(checkout) };
        }
        return object;
    };

    that.merchantInfo = function () {
        let cache = CacheMgr.getCache('payplanCache');
        let integrationKey = breadData.getIntegrationKey();
        let data = cache.get(integrationKey);
        if (data) {
            return data;
        }

        service.setRequestMethod('GET');
        service.setURL(apiUrl + '/api/experience-keys/' + integrationKey);
        service.addHeader('Content-Type', 'application/json');

        let response = service.call();
        let object = false;
        if (response.ok && !response.object.errorText) {
            try {
                object = JSON.parse(response.object.text);
                cache.put(integrationKey, object);
                return object;
            } catch (e) {
                object = { error: true, status: e.message };
            }
        }
        return object;
    };

    that.merchantLocation = function () {
        let merchantInfo = that.merchantInfo();
        let getTokenResult = that.getToken();
        if (!getTokenResult.token) {
            return getTokenResult;
        }
        service.setRequestMethod('GET');
        service.setURL(apiUrl + '/api/organization/merchant/' + merchantInfo.merchantID + '/location');
        service.addHeader('Content-Type', 'application/json');
        service.addHeader('Authorization', 'Bearer ' + getTokenResult.token);
        service.addHeader('X-API-VERSION', 'v2');

        let response = service.call();
        let object = false;
        if (response.ok && !response.object.errorText) {
            try {
                return response.object.text;
            } catch (e) {
                object = { error: true, status: e.message };
            }
        }
        return object;
    };

    that.asLowAs = function (amount) {
        amount = Math.round(amount * 100);
        let cache = CacheMgr.getCache('payplanCache');
        let data = cache.get(amount);
        if (data) {
            return JSON.stringify(data);
        }

        let merchantInfo = that.merchantInfo();
        service.setRequestMethod('GET');
        service.setURL(apiUrl + '/api/experience/servicing/as-low-as?merchantId=' + merchantInfo.merchantID + "&programId=" + merchantInfo.programID + "&amount=" + amount);
        service.addHeader('Content-Type', 'application/json');

        let response = service.call();
        let object = false;
        if (response.ok && !response.object.errorText) {
            try {
                object = JSON.parse(response.object.text);
                cache.put(amount, object);
                return JSON.stringify(object);
            } catch (e) {
                object = { error: true, status: e.message };
            }
        }
        return object;
    };

    that.getToken = function () {
        if (session.privacy.apiToken && session.privacy.tokenExpiresAt) {
            if (Date.parse(session.privacy.tokenExpiresAt) - Date.now() > 0) {
                return { token: session.privacy.apiToken };
            }
        }
        service.setRequestMethod('POST');
        service.setURL(authUrl);
        service.addHeader('Content-Type', 'application/json');
        let param = {
            apiKey: breadData.getApiKey(),
            secret: breadData.getApiSecret(),
        };
        let response = service.call(JSON.stringify(param));
        let object;
        if (response.ok) {
            try {
                object = JSON.parse(response.object.text);
                if (object.token && object.tokenExpiresAt) {
                    session.privacy.apiToken = object.token;
                    session.privacy.tokenExpiresAt = object.tokenExpiresAt.replace(/\.(.*?)Z/, '');
                }
            } catch (e) {
                object = { error: true, msg: e.message };
            }
        } else {
            object = { error: true, msg: response.errorMessage };
        }
        return object;
    };

    that.saveSettings = function() {
        let request = {
            storeId: Site.current.name,
            pluginType: "SFCC",
            integrationKey: breadData.getIntegrationKey(),
            //sandboxIntegrationKey: "",
            breadApiKey: breadData.getApiKey(),
            //breadApiKeySandbox: "",
            breadSecretKey: breadData.getApiSecret(),
            //breadSecretKeySandbox: "",
            production: breadData.getEnvironment() !== "sandbox",
            settlementMode: breadData.isSettleEnabled() ? "CHECKOUT" : "FULFILLMENT",
            skuFilter: breadData.getSkuFilter(),
            skuFilterMode: breadData.isSkuFilteringEnabled(),
            minCartValue: breadData.getMinCartSize(),
            minCartMode: breadData.isCartSizeFilteringEnabled(),
            enableProductButton: breadData.isProductPagePlacementEnabled(),
            enableCartButton: breadData.isCartPagePlacementEnabled(),
            enableEmbeddedCheckout: breadData.isEmbeddedCheckoutEnabled(),
            //customData: "",
            //customDataEncrypted: "",
        }
        let getTokenResult = that.getToken();
        if (!getTokenResult.token) {
            return getTokenResult;
        }
        service.setRequestMethod('POST');
        service.setURL(apiUrl + '/api/core-plugin-backend/settings');
        service.addHeader('Content-Type', 'application/json');
        service.addHeader('Authorization', 'Bearer ' + getTokenResult.token);

        let response = service.call(JSON.stringify(request));
        let object = {};
        if (response.ok) {
            // try catch error
            try {
                object = JSON.parse(response.object.text);
            } catch (e) {
                object = { error: true, msg: e.message };
            }
        } else {
            object = { error: true, msg: response.errorMessage, request: JSON.stringify(request) };
        }
        return object;
    }
};

module.exports = new Calls();
