/**
* TEST CONTROLLER SHOULD BE REMOVED!!!
* This controller gives access to transaction on PAYPLAN side
* and should be removed, because it allows to manipulate with payment amount of transactions
*
* how to:
* call https://{YOUR SITE}/on/demandware.store/Sites-RefArch-Site/en_US/Test-Bread?orderId=xxx&action=xxx
*
* @module  controllers/Test
*/

'use strict';
let server = require('server');

server.get('Bread', function (req, res, next) {
    let BreadServiceHelper = require('*/cartridge/scripts/lib/breadData.js').getBreadServiceHelper();
    let orderId = request.httpParameterMap.orderId.stringValue || null;
    let action = request.httpParameterMap.action.stringValue || null;
    let amount = request.httpParameterMap.amount.stringValue || null;
    let items = request.httpParameterMap.items.stringValue || null;
    let OrderMgr = require('dw/order/OrderMgr');
    let order = OrderMgr.queryOrder('orderNo = {0}', orderId);
    let result;
    if (order) {
        result = !action ? 'please provide action' : '';
    } else {
        result = 'order does not exist';
    }
    if (order && action) {
        switch (action) {
            case 'retrieve':
                result = BreadServiceHelper.getTransaction(order.custom.payplan_token);
                break;
            case 'cancel':
            case 'settle':
            case 'refund':
            case 'authorize':
                try {
                    let data = JSON.parse(items);
                    result = BreadServiceHelper.actionTransaction(order, action, amount, data);
                } catch (e) {
                    result = { error: true, message: e.message };
                }
                break;
            default:
                result = 'provide correct action name: retrieve, cancel, settle, refund, authorize';
                break;
        }
    }
    res.json(result);
    return next();
});

module.exports = server.exports();
