'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru().noPreserveCache();
var Site = require('../../../mocks/dw/system/Site');
var URLUtils = require('../../../mocks/dw/web/URLUtils');
var currentSite = Site.getCurrent();
var serviceInit = require('../../../mocks/scripts/service/serviceInit');
var Transaction = require('../../../mocks/dw/system/Transaction');
var Order = require('../../../mocks/dw/order/Order');

var breadServiceV2Helper = proxyquire('../../../../cartridges/int_bread/cartridge/scripts/service/breadServiceV2Helper', {
    '*/cartridge/scripts/lib/breadData.js' : proxyquire('../../../../cartridges/int_bread/cartridge/scripts/lib/breadData', {
        'dw/system/Site': Site,
        'dw/web/URLUtils': URLUtils
    }),
    '*/cartridge/scripts/service/breadInit.js' : serviceInit,
    'dw/system/Transaction' : Transaction,
    'dw/order/Order' : Order
});

var breadData = proxyquire('../../../../cartridges/int_bread/cartridge/scripts/lib/breadData', {
    'dw/system/Site': Site,
    'dw/web/URLUtils': URLUtils,
    '*/cartridge/scripts/service/breadServiceV2Helper.js': breadServiceV2Helper
});

describe('breadData - Test main data functions used in the cartridge', function () {
    beforeEach(function () {
        currentSite.customPreferences.bread_enable = true;
        currentSite.customPreferences.bread_apiKey = 'f54a9e07-b9af-4dbe-bbfb-99bb27da36f5';
        currentSite.customPreferences.bread_integrationKey = 'integration_key';
        currentSite.customPreferences.bread_environment = {
            display: 'SANDBOX',
            value: 'sandbox'
        };
        currentSite.customPreferences.bread_authorizeAndSettle = true;
    });

    describe('isBreadEnabled(), function return state of custom preference setting bread_enable', function () {
        it('Check Site preference bread_enable', function () {
            assert.isTrue(breadData.isBreadEnabled());
        });
    });

    describe('getApiKey(), function return state of custom preference setting bread_apiKey', function () {
        it('Check Site preference bread_apiKey', function () {
            assert.equal(breadData.getApiKey(), 'f54a9e07-b9af-4dbe-bbfb-99bb27da36f5');
        });
    });

    describe('getEnvironment(), function return state of custom preference setting bread_environment', function () {
        it('Check Site preference bread_environment', function () {
            assert.equal(breadData.getEnvironment(), 'sandbox');
        });
    });

    describe('getClientApiUrl(), function return API URL based on account type (getEnvironment())', function () {
        it('Check function getClientApiUrl()', function () {
            assert.equal(breadData.getClientApiUrl(), 'https://connect-preview.breadpayments.com/sdk.js');
        });
    });

    describe('getServerApiUrl(), function return server API URL based on account type (getEnvironment())', function () {
        it('Check function getServerApiUrl()', function () {
            assert.equal(breadData.getServerApiUrl(), 'https://api-preview.platform.breadpayments.com');
        });
    });

    describe('isSettleEnabled(), function return state of custom preference setting bread_authorizeAndSettle', function () {
        it('Check Site preference bread_authorizeAndSettle', function () {
            currentSite.customPreferences.bread_authorizeAndSettle = true;
            assert.isTrue(breadData.isSettleEnabled());
            currentSite.customPreferences.bread_authorizeAndSettle = false;
            assert.isNotTrue(breadData.isSettleEnabled());
        });
    });

    describe('getButtonActionUrl(), function return button action URL depending on the site type', function () {
        it('Check function getButtonActionUrl()', function () {
            assert.equal(breadData.getButtonActionUrl(true), 'CheckoutServices-PlaceOrder');
        });
    });

    describe('getIntegrationKey(), function return state of custom preference setting bread_integrationKey', function () {
        it('Check Site preference bread_integrationKey', function () {
            assert.equal(breadData.getIntegrationKey(), 'integration_key');
        });
    });

    describe('getBreadServiceHelper(), function return service helper', function () {
        it('Check function getBreadServiceHelper()', function () {
            assert.equal(breadData.getBreadServiceHelper(), breadServiceV2Helper);
        });
    });

    describe('getAuthUrl(), function return authentication URL based on account type (getEnvironment())', function () {
        it('Check function getAuthUrl()', function () {
            assert.equal(breadData.getAuthUrl(), 'https://api.sp-pv-ads.ue2.breadgateway.net/api/auth/sa/authenticate');
        });
    });
});
