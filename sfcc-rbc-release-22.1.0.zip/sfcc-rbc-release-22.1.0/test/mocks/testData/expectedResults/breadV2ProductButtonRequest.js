module.exports = {
    order: '{"items":[{"name":"Navy Single Pleat Wool Suit","sku":"750518548296M","category":"","unitPrice":29999,"unitTax":0,"brand":"","currency":"USD","quantity":1,"shippingCost":0,"shippingDescription":""}],"currency":"USD","subTotal":29999,"totalPrice":29999,"totalShipping":0,"totalDiscounts":0,"totalTax":0}'
};
