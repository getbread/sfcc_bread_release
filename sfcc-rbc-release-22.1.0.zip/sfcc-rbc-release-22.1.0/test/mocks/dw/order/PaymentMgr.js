var PaymentMethod = require('./PaymentMethod');
var PaymentMgr = function () {};

PaymentMgr.getPaymentMethod = function (id) {
    var paymentMethod;
    switch (id) {
        case 'METHOD_CREDIT_CARD':
            paymentMethod = new PaymentMethod();
            paymentMethod.paymentProcessor = { ID: 'BASIC_CREDIT' };
            break;
        case 'BREAD':
            paymentMethod = new PaymentMethod();
            paymentMethod.paymentProcessor = { ID: 'BREAD' };
            break;
        default:
            paymentMethod = null;
            return paymentMethod;
    }
};
PaymentMgr.getApplicablePaymentMethods = function () {};
PaymentMgr.getPaymentCard = function () {};
PaymentMgr.getActivePaymentMethods = function () {};
PaymentMgr.prototype.paymentMethod = null;
PaymentMgr.prototype.applicablePaymentMethods = null;
PaymentMgr.prototype.paymentCard = null;
PaymentMgr.prototype.activePaymentMethods = null;

module.exports = PaymentMgr;
