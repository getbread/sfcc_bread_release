var Session = require('./system/Session');
var Product = require('../testData/demoData/product');

global.empty = function (obj) {
    if (obj === null || obj === undefined || obj === '' || (typeof (obj) !== 'function' && obj.length !== undefined && obj.length === 0)) {
        return true;
    }
    return false;
};

global.session = new Session();

global.String.prototype.equals = function (object) {
    return (typeof object === 'string') && object === this.valueOf();
};

global.dw = {
    catalog: {
        Product: Product
    }
};
