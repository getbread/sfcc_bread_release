'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru().noPreserveCache();
var URLUtils = require('../../../mocks/dw/web/URLUtils');
var Money = require('../../../mocks/dw/value/Money');
var Site = require('../../../mocks/dw/system/Site');
require('../../../mocks/dw/globals');

var breadData = proxyquire('../../../../cartridges/int_bread/cartridge/scripts/lib/breadData', {
    'dw/system/Site': Site,
    'dw/web/URLUtils': URLUtils
});

var breadHelper = proxyquire('../../../../cartridges/int_bread/cartridge/scripts/lib/breadHelper', {
    '*/cartridge/scripts/lib/breadData.js': breadData,
    'dw/web/URLUtils': URLUtils,
    'dw/value/Money': Money
});


describe('breadHelper - Test helper util, used for requests', function () {
    describe('prepareRequest(), function prepare object for request', function () {
        it('Check if prepared object is as expected', function () {
            var requestToCheck = require('../../../mocks/testData/expectedResults/breadButtonRequest');
            var Basket = require('../../../mocks/testData/demoData/basket');
            var basketToWorkWith = new Basket();
            assert.deepEqual(breadHelper.prepareRequest(basketToWorkWith), requestToCheck);
        });
    });

    describe('prepareRequestForPdpButton(), function prepare object for request on PDP', function () {
        it('Check if prepared object is as expected', function () {
            var requestToCheck = require('../../../mocks/testData/expectedResults/breadProductButtonRequest');
            var Product = require('../../../mocks/testData/demoData/product');
            var productToWorkWith = [new Product()];
            assert.deepEqual(breadHelper.prepareRequestForPdpButton(productToWorkWith), requestToCheck);

            productToWorkWith = [{ raw: new Product() }];
            assert.deepEqual(breadHelper.prepareRequestForPdpButton(productToWorkWith), requestToCheck);
        });
    });
});
