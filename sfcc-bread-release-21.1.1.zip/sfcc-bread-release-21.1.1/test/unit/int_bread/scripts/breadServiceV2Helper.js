'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru().noPreserveCache();
var Site = require('../../../mocks/dw/system/Site');
var currentSite = Site.getCurrent();
var URLUtils = require('../../../mocks/dw/web/URLUtils');
var Transaction = require('../../../mocks/dw/system/Transaction');
var Order = require('../../../mocks/dw/order/Order');
var Money = require('../../../mocks/dw/value/Money');
var serviceInit = require('../../../mocks/scripts/service/serviceInit');

var breadData = proxyquire('../../../../cartridges/int_bread/cartridge/scripts/lib/breadData', {
    'dw/system/Site'  : Site,
    'dw/web/URLUtils' : URLUtils
});

var breadServiceV2Helper = proxyquire('../../../../cartridges/int_bread/cartridge/scripts/service/breadServiceV2Helper', {
    '*/cartridge/scripts/lib/breadData.js' : breadData,
    '*/cartridge/scripts/service/breadInit.js' : serviceInit,
    'dw/system/Transaction' : Transaction,
    'dw/order/Order' : Order
});

require('../../../mocks/dw/globals');

describe('breadServiceV2Helper - Test helper util, used for new API requests', function () {
    before(function () {
        //currentSite.customPreferences.bread_useNewBreadAPI = true;
        currentSite.customPreferences.bread_environment = {
            display: 'TEST - BreadPay',
            value: 'bread_sandbox'
        };
    });

    after(function () {
        //currentSite.customPreferences.bread_useNewBreadAPI = false;
        currentSite.customPreferences.bread_environment = {
            display: 'TEST - BreadClassic',
            value: 'classic_sandbox'
        };
    })

    describe('getToken(), function to make a call to service to request token or get token from session', function () {
        it('Check if response object from service call is as expected and data is saved to session', function () {
            let responseOk = {
                token: "token",
                tokenExpiresAt: "2030-04-21T08:34:10.908505125Z"
            }

            assert.deepEqual(breadServiceV2Helper.getToken(), responseOk);
            assert.equal(global.session.privacy.apiToken, responseOk.token);
            assert.equal(global.session.privacy.tokenExpiresAt, responseOk.tokenExpiresAt.replace(/\.(.*?)Z/, ''));
        });

        it('Check if token is taken from session data and result object is as expected', function () {
            let result = {
                token: "token",
            }

            assert.deepEqual(breadServiceV2Helper.getToken(), result);
        });
    });

    describe('getTransaction(), function to make a call to service', function () {
        it('Check if response object is as expected', function () {
            let responseOk = {
                "status":"PENDING"
            }
            let order = {
                currencyCode: 'USD',
                custom: {
                    bread_status: ''
                }
            }
            assert.deepEqual(breadServiceV2Helper.getTransaction('123', order), responseOk);
        });
    });

    describe('actionTransaction(), function to make a call to service', function () {
        it('Check if response object is as expected', function () {
            let responseOk = {
                "status":"SETTLED"
            }
            let order = {
                currencyCode: 'USD',
                custom: {
                    bread_status: '',
                    bread_token: '123'
                }
            }
            assert.deepEqual(breadServiceV2Helper.actionTransaction(order, "authorize"), responseOk);
        });
    });

});