// initialize BreadService
var useNewBreadApi = require('*/cartridge/scripts/lib/breadData.js').useNewBreadApi();
var serviceID = useNewBreadApi ? 'int_bread.https.serviceV2' : 'int_bread.https.service';

var breadTenant = require('*/cartridge/scripts/lib/breadData.js').getBreadTenant();
if (String(breadTenant) === 'RBCPayPlan') {
    serviceID = 'int_bread.https.serviceRBC';
}

var initBreadService = require('dw/svc/LocalServiceRegistry').createService(serviceID, {
    createRequest: function (service, params) {
        service.setAuthentication('BASIC');
        // if get there is no body to send
        return params || '';
    },

    parseResponse: function (service, response) {
        return response;
    },

    getRequestLogMessage: function (data) {
        return data;
    },

    getResponseLogMessage: function (data) {
        var response = !empty(data.text) ? data.text : data;
        return response;
    }
});
module.exports = initBreadService;

