'use strict';

var server = require('server');

/* API includes */
var BasketMgr = require('dw/order/BasketMgr');
var URLUtils = require('dw/web/URLUtils');
var csrfProtection = require('*/cartridge/scripts/middleware/csrf');

server.extend(module.superModule);

/**
 *  Clear Bread payment instrument
 */
server.prepend(
    'SubmitPayment',
    server.middleware.https,
    csrfProtection.validateAjaxRequest,
    function (req, res, next) {
        var Transaction = require('dw/system/Transaction');
        var collections = require('*/cartridge/scripts/util/collections');

        var currentBasket = BasketMgr.getCurrentBasket();
        if (currentBasket) {
            Transaction.wrap(function () {
                var paymentInstruments = currentBasket.getPaymentInstruments('BREAD');
                collections.forEach(paymentInstruments, function (item) {
                    currentBasket.removePaymentInstrument(item);
                });
            });
        }
        return next();
    }
);

/* just to pass BREAD payment method through PlaceOrder controller */
server.prepend('PlaceOrder', function (req, res, next) {
    var paymentInstruments = BasketMgr.getCurrentBasket().getPaymentInstruments().iterator();

    while (paymentInstruments.hasNext()) {
        var paymentInsturment = paymentInstruments.next();
        if (paymentInsturment.paymentMethod === 'BREAD') {
            session.privacy.BREAD = 'BREAD';
            break;
        }
    }

    next();
});

/* redirect to native order confirmation page */
server.append('PlaceOrder', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var CartModel = require('*/cartridge/models/cart');
    var currentBasket;
    var basketModel;
    if (session.privacy && session.privacy.BREAD === 'BREAD') {
        session.privacy.BREAD = '';
        if (res.viewData.orderID) {
            if (!res.viewData.error) {
                var orderId = res.viewData.orderID;
                var orderToken = res.viewData.orderToken;
                res.setRedirectStatus(307);
                res.redirect(URLUtils.https('Order-Confirm', 'ID', orderId, 'token', orderToken).toString());
            } else {
                currentBasket = BasketMgr.getCurrentBasket();
                basketModel = new CartModel(currentBasket);
                basketModel.valid = {
                    error: true,
                    message: Resource.msg('error.technical', 'checkout', null)
                };
                res.render('cart/cart', basketModel);
                return next();
            }
        }
    }
    if (res.viewData.error) {
        currentBasket = BasketMgr.getCurrentBasket();
        basketModel = new CartModel(currentBasket);
        basketModel.valid = {
            error: true,
            message: Resource.msg('error.technical', 'checkout', null)
        };
        res.render('cart/cart', basketModel);
        return next();
    }
    return next();
});

module.exports = server.exports();
