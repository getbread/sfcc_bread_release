/**
* @module  controllers/BreadHandler
*/

'use strict';
/* Script Modules */
var guard = require('*/cartridge/scripts/guard');
var app = require('*/cartridge/scripts/app');
var URLUtils = require('dw/web/URLUtils');

/**
* Just redirect with csrf protection to avoid vulnerability
*
*/
var checkout = function () {
    response.redirect(URLUtils.https('COSummary-Submit'), 307);
};

/**
* Renders Bread button for product set details page
*
*/
var buttonPS = function () {
    var ProductMgr = require('dw/catalog/ProductMgr');
    var breadData = require('*/cartridge/scripts/lib/breadData.js');
    var params = request.httpParameterMap;
    var pidsArray = JSON.parse(params.pids.stringValue);
    var setProducts = pidsArray.map(function (productID) {
        return ProductMgr.getProduct(productID);
    });
    var template = breadData.useNewBreadApi() ? 'bread/buttonOnPdpV2' : 'bread/buttonOnPdp';

    app.getView({
        isSet: true,
        ProductSetList: setProducts
    }).render(template);
};

exports.Checkout = guard.ensure(['https', 'post', 'csrf'], checkout);
exports.ButtonPS = guard.ensure(['https', 'get'], buttonPS);

