'use strict';
var Url = function (id) {
    this.toString = function () {
        return id;
    };
};

var dataToCheck = {
    productDetailUrl: 'https://astound32-alliance-prtnr-eu04-dw.demandware.net/s/Bread_SFRA/navy-single-pleat-wool-suit/750518548296M.html?lang=en_US'
};

module.exports = {
    http: function (id) {
        return new Url(id);
    },
    https: function (id) {
        return new Url(id);
    },
    staticURL: function () {
        return 'some url';
    },
    url: function () {
        return 'someUrl';
    },
    abs: function (id) {
        var str = id;
        if (id == 'Product-Show') {
            str = dataToCheck.productDetailUrl;
        }
        return new Url(str);
    }
};
