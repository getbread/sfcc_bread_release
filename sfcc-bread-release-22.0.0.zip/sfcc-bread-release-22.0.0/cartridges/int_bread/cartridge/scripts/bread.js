(function() {
    let OrderMgr = require('dw/order/OrderMgr');
    let Order = require('dw/order/Order');

// Local includes
    let data = require('int_bread/cartridge/scripts/lib/breadData');
    let breadHelper = require('int_bread/cartridge/scripts/lib/breadV2Helper');
    let logger = require('dw/system').Logger.getLogger('Bread', '');

    /**
     * Settle orders
     * @returns {boolean} - job response
     */
    function settleOrders() {
        let service = data.getBreadServiceHelper();
        if (data.isBreadEnabled()) {
            OrderMgr.processOrders(function (order) {
                try {
                    logger.info('Processing order {0}', order.orderNo);
                    let orderTotal = breadHelper.priceToInteger(breadHelper.getNonGiftCertificateOrderAmount(order));
                    let status = service.actionTransaction(order, 'settle', orderTotal);
                    if (status.error) {
                        logger.error("Failed to process order {0}, msg: {1}", order.orderNo, status.msg);
                        return;
                    }
                    order.custom.bread_status = 'SETTLED';
                    order.setPaymentStatus(Order.PAYMENT_STATUS_PAID);
                    order.setStatus(Order.ORDER_STATUS_COMPLETED);
                } catch (e) {
                    logger.error('Failed to process order.  Error: {0}', e);
                }
            }, '(status = {0} OR status = {1} OR status = {2}) AND shippingStatus = {3} AND custom.bread_token != NULL AND custom.bread_status = {4}', Order.ORDER_STATUS_NEW, Order.ORDER_STATUS_OPEN, Order.ORDER_STATUS_COMPLETED, Order.SHIPPING_STATUS_SHIPPED, "AUTHORIZED");
        }
        return true;
    }

    /**
     * Refund orders
     * @returns {boolean} - job response
     */
    function refundOrders() {
        let service = data.getBreadServiceHelper();
        if (data.isBreadEnabled()) {
            OrderMgr.processOrders(function (order) {
                try {
                    logger.info('Processing order {0}', order.orderNo);
                    let orderTotal = breadHelper.priceToInteger(breadHelper.getNonGiftCertificateOrderAmount(order));
                    let status = service.actionTransaction(order, 'refund', orderTotal);
                    if (status.error) {
                        logger.error("Failed to process order {0}, msg: {1}", order.orderNo, status.msg);
                        return;
                    }
                    order.custom.bread_status = 'REFUNDED';
                } catch (e) {
                    logger.error('Failed to process order.  Error: {0}', e);
                }
            }, 'status = {0} AND custom.bread_token != NULL AND custom.bread_status = {1}', Order.ORDER_STATUS_CANCELLED, "SETTLED");
        }
        return true;
    }

    /**
     * Cancel orders
     * @returns {boolean} - job response
     */
    function cancelOrders() {
        let service = data.getBreadServiceHelper();
        if (data.isBreadEnabled()) {
            OrderMgr.processOrders(function (order) {
                try {
                    logger.info('Processing order {0}', order.orderNo);
                    let orderTotal = breadHelper.priceToInteger(breadHelper.getNonGiftCertificateOrderAmount(order));
                    let status = service.actionTransaction(order, 'cancel', orderTotal);
                    if (status.error) {
                        logger.error("Failed to process order {0}, msg: {1}", order.orderNo, status.msg);
                        return;
                    }
                    order.custom.bread_status = 'CANCELLED';
                } catch (e) {
                    logger.error('Failed to process order.  Error: {0}', e);
                }
            }, 'status = {0} AND custom.bread_token != NULL AND custom.bread_status = {1}', Order.ORDER_STATUS_CANCELLED, "AUTHORIZED");
        }
        return true;
    }

    /**
     * Updates shipping information
     * @returns {boolean} - job response
     */
    function addShippingInfo() {
        let service = data.getBreadServiceHelper();
        if (data.isBreadEnabled()) {
            OrderMgr.processOrders(function (order) {
                try {
                    let orderShipment = order.getDefaultShipment();
                    let shippingRequest = {};
                    if (orderShipment.shippingMethod && orderShipment.shippingMethod.displayName) {
                        shippingRequest.carrier = orderShipment.shippingMethod.displayName;
                    }
                    if (orderShipment.trackingNumber) {
                        shippingRequest.trackingNumber = orderShipment.trackingNumber;
                    }
                    let status = service.updateShipping(order, shippingRequest);
                    if (status.error) {
                        logger.error("Failed to process shipping for order {0}, msg: {1}", order.orderNo, status.msg);
                        return;
                    }
                    order.custom.bread_shipping_status = 'SHIPPED';
                } catch (e) {
                    logger.error('Failed to process shipping information.  Error: {0}', e);
                }
            }, 'shippingStatus = {0} AND custom.bread_token != NULL AND custom.bread_shipping_status != {1}', Order.SHIPPING_STATUS_SHIPPED, "SHIPPED");
        }
        return true;
    }

    module.exports = {
        addShippingInfo: addShippingInfo,
        cancelOrders: cancelOrders,
        refundOrders: refundOrders,
        settleOrders: settleOrders,
    };
}())