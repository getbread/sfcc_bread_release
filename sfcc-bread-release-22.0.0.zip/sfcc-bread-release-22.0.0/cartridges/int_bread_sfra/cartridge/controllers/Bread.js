'use strict';
let server = require('server');
// just to have ajax access to button
server.get('Button', function (req, res, next) {
    let buttonLocation = req.querystring.location;
    if (!buttonLocation) {
        let checkoutButtonTemplate = 'bread/buttonOnCheckoutV2';
        res.render(checkoutButtonTemplate);
        return next();
    }
    if (buttonLocation === 'cart') {
        let cartButtonTemplate = 'bread/buttonOnCartV2';
        res.render(cartButtonTemplate);
        return next();
    }
    if (buttonLocation === 'pdp') {
        let ProductMgr = require('dw/catalog/ProductMgr');
        let pdpButtonTemplate = 'bread/buttonOnPdpV2';
        let viewData = {
            product: {}
        };
        if (req.querystring.pids) {
            let pidsArray = JSON.parse(req.querystring.pids);
            viewData.product.productType = 'set';
            viewData.product.individualProducts = pidsArray.map(function (productID) {
                return ProductMgr.getProduct(productID);
            });
        } else {
            viewData.product = ProductMgr.getProduct(req.querystring.pid);
        }
        res.render(pdpButtonTemplate, viewData);
        return next();
    }

    return next();
});

module.exports = server.exports();
