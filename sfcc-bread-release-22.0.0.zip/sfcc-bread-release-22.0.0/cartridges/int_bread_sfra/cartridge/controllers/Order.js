'use strict';

let server = require('server');

server.extend(module.superModule);

let Resource = require('dw/web/Resource');
let URLUtils = require('dw/web/URLUtils');
let csrfProtection = require('*/cartridge/scripts/middleware/csrf');
let consentTracking = require('*/cartridge/scripts/middleware/consentTracking');

server.replace(
    'Confirm',
    consentTracking.consent,
    server.middleware.https,
    csrfProtection.generateToken,
    function (req, res, next) {
        let reportingUrlsHelper = require('*/cartridge/scripts/reportingUrls');
        let OrderMgr = require('dw/order/OrderMgr');
        let OrderModel = require('*/cartridge/models/order');
        let Locale = require('dw/util/Locale');

        let order;

        let orderID = (req.form && req.form.orderID) || req.querystring.ID;
        let orderToken = (req.form && req.form.orderToken) || req.querystring.token;

        if (!orderToken || !orderID) {
            res.render('/error', {
                message: Resource.msg('error.confirmation.error', 'confirmation', null)
            });

            return next();
        }

        order = OrderMgr.getOrder(orderID, orderToken);

        if (!order || order.customer.ID !== req.currentCustomer.raw.ID
        ) {
            res.render('/error', {
                message: Resource.msg('error.confirmation.error', 'confirmation', null)
            });

            return next();
        }
        let lastOrderID = Object.prototype.hasOwnProperty.call(req.session.raw.custom, 'orderID') ? req.session.raw.custom.orderID : null;
        if (lastOrderID === req.querystring.ID) {
            res.redirect(URLUtils.url('Home-Show'));
            return next();
        }

        let config = {
            numberOfLineItems: '*'
        };

        let currentLocale = Locale.getLocale(req.locale.id);

        let orderModel = new OrderModel(
            order,
            { config: config, countryCode: currentLocale.country, containerView: 'order' }
        );
        let passwordForm;

        let reportingURLs = reportingUrlsHelper.getOrderReportingURLs(order);

        if (!req.currentCustomer.profile) {
            passwordForm = server.forms.getForm('newPasswords');
            passwordForm.clear();
            res.render('checkout/confirmation/confirmation', {
                order: orderModel,
                returningCustomer: false,
                passwordForm: passwordForm,
                reportingURLs: reportingURLs,
                orderUUID: order.getUUID()
            });
        } else {
            res.render('checkout/confirmation/confirmation', {
                order: orderModel,
                returningCustomer: true,
                reportingURLs: reportingURLs,
                orderUUID: order.getUUID()
            });
        }
        req.session.raw.custom.orderID = req.querystring.ID; // eslint-disable-line no-param-reassign
        return next();
    }
);

module.exports = server.exports();
