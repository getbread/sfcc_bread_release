/* API Includes */
let Transaction = require('dw/system/Transaction');
let Resource = require('dw/web/Resource');
let collections = require('*/cartridge/scripts/util/collections');
let breadHelper = require('*/cartridge/scripts/lib/breadV2Helper');
/**
 * Handles a payment using  BREAD. The payment is handled by using the BREAD processor
 * basket, paymentInformation
 * @param {Basket} basket - basket
 * @param {Object} paymentInformation - paymentInformation
 * @returns {Object} - response
 */
function Handle(basket) {
    let cardErrors = {};
    let serverErrors = [];
    try {
        let currentBasket = basket;
        Transaction.wrap(function () {
            let paymentInstruments = currentBasket.getPaymentInstruments();
            collections.forEach(paymentInstruments, function (item) {
                currentBasket.removePaymentInstrument(item);
            });
            currentBasket.createPaymentInstrument(
                'BREAD', currentBasket.totalGrossPrice
            );
        });
    } catch (e) {
        serverErrors.push(
            Resource.msg('error.technical', 'checkout', null)
        );
        return { fieldErrors: cardErrors, serverErrors: serverErrors, error: true };
    }
    return { fieldErrors: cardErrors, serverErrors: serverErrors, error: false };
}

/**
 * Authorizes a payment using  BREAD. The payment is authorized by using the BREAD processor
 * @param {string} orderNumber - basket
 * @param {Object} paymentInstrument - paymentInstrument
 * @param {string} paymentProcessor - paymentProcessor
 * @param {string} orderToken - orderToken
 * @returns {Object} - response
 */
function Authorize(orderNumber, paymentInstrument, paymentProcessor, orderToken) {
    let serverErrors = [];
    let fieldErrors = {};
    let error = false;
    let token = request.httpParameterMap.token
        ? request.httpParameterMap.token.value
        : false;
    let order = dw.order.OrderMgr.getOrder(orderNumber, orderToken);
    let breadServiceHelper = require('*/cartridge/scripts/lib/breadData.js').getBreadServiceHelper();
    let orderTotal = breadHelper.priceToInteger(order.getTotalGrossPrice());

    if (token) {
        // check the transaction on BREAD side
        let transaction = breadServiceHelper.getTransaction(token);
        let txnTotal = transaction.total || transaction.totalAmount.value;
        Transaction.wrap(function () {
            order.custom.bread_token = token;
            order.custom.bread_transaction_type = transaction.productType;
            paymentInstrument.paymentTransaction.setTransactionID(orderNumber);
            paymentInstrument.paymentTransaction.setPaymentProcessor(paymentProcessor);
        });
        // if basket was changed during BREAD checkout we will not place order
        if (txnTotal !== orderTotal) {
            breadServiceHelper.actionTransaction(order, 'cancel', orderTotal);
            error = true;
            serverErrors.push(
                Resource.msg('error.technical', 'checkout', null)
            );
        }
    } else {
        error = true;
        serverErrors.push(
            Resource.msg('error.technical', 'checkout', null)
        );
    }
    breadServiceHelper.actionTransaction(order, 'authorize', orderTotal);
    breadServiceHelper.updateOrderNumber(order);

    return { fieldErrors: fieldErrors, serverErrors: serverErrors, error: error };
}

exports.Handle = Handle;
exports.Authorize = Authorize;
