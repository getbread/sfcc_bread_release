
/* API Includes */
let Transaction = require('dw/system/Transaction');
let Cart = require('*/cartridge/scripts/models/CartModel');
let PaymentMgr = require('dw/order/PaymentMgr');
let breadHelper = require('*/cartridge/scripts/lib/breadV2Helper');
/**
 * Handles a payment using  BREAD. The payment is handled by using the BREAD processor
 * @param {Object} args - object of arguments to work with
 * @return {Object} - error or success
 */
function Handle(args) {
    try {
        let cart = Cart.get(args.Basket);
        Transaction.wrap(function () {
            cart.removeExistingPaymentInstruments('BREAD');
            cart.createPaymentInstrument('BREAD', cart.getNonGiftCertificateAmount());
        });
    } catch (e) {
        return { error: true };
    }

    return { success: true };
}

/**
 * Authorizes a payment using  BREAD. The payment is authorized by using the BREAD processor
 * @param {Object} args - object of arguments to work with
 * @return {Object} - error or authorized
 */
function Authorize(args) {
    let token = request.httpParameterMap.token
        ? request.httpParameterMap.token.value
        : false;

    let paymentInstrument = args.PaymentInstrument;
    let paymentProcessor = PaymentMgr.getPaymentMethod(paymentInstrument.getPaymentMethod()).getPaymentProcessor();
    let breadServiceHelper = require('*/cartridge/scripts/lib/breadData.js').getBreadServiceHelper();
    let orderTotal = breadHelper.priceToInteger(breadHelper.getNonGiftCertificateOrderAmount(args.Order));

    if (token) {
        let transaction = breadServiceHelper.getTransaction(token);
        let txnTotal = transaction.total || transaction.totalAmount.value;
        Transaction.wrap(function () {
            args.Order.custom.bread_token = token; // eslint-disable-line no-param-reassign
            args.Order.custom.bread_transaction_type = transaction.productType;
            paymentInstrument.paymentTransaction.paymentProcessor = paymentProcessor;
        });
        // if basket was changed during BREAD checkout we will not place order
        if (txnTotal !== orderTotal) {
            breadServiceHelper.actionTransaction(args.Order, 'cancel', orderTotal);
            return { error: true };
        }
    } else {
        return { error: true };
    }
    breadServiceHelper.actionTransaction(args.Order, 'authorize', orderTotal);
    breadServiceHelper.updateOrderNumber(args.Order);

    return { authorized: true };
}

exports.Handle = Handle;
exports.Authorize = Authorize;

