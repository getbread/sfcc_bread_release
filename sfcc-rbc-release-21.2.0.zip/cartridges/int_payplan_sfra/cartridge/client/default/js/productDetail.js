'use strict';

let processInclude = require('base/util');

$(document).ready(function () {
    processInclude(require('./product/detail'));
});
