document.addEventListener('DOMContentLoaded', function () {
    $('#emailBread').val($('input#email').val());
    if ($('#bread-checkout-btn').length > 0) {
        $('.place-order').hide();
    }
    // changing Bread button styling on checkout
    $('body').on('DOMNodeInserted', function (e) {
        if (e.originalEvent.relatedNode.id === 'bread-checkout-btn') {
            let buttonText = $('#bread-checkout-btn').data('btn-text');
            $('#bread-checkout-btn div a').addClass('btn btn-block btn-primary').text(buttonText);
        }
    });
	// sending Ajax to Bread-Button end point
    $('body').on('checkout:updateCheckoutView', function () {
        if ($('.payment-information').data('payment-method-id') === 'PAYPLAN') {
            $('div[id^="zoid-checkout-component-"]').empty();
            $.ajax({
                url: $('#js_breadsummary').data('action'),
                success: function (data) {
                    $('#js_breadsummary').html('Bread:' + data);
                }
            });
			$('.payment-details').hide();
            if (typeof bread !== 'undefined' || typeof BreadPayments !== 'undefined' || typeof RBCPayPlan !== 'undefined') {
                $('.place-order').hide();
            }
        } else {
            $('.place-order').removeAttr('style');
        }
    });
	// toggle payment method IDs in the data attribute of payment information
    $('.payment-options .nav-item').on('click', function (e) {
        e.preventDefault();
        let methodID = $(this).data('method-id');
        $('input[name$="paymentMethod"]').val(methodID);
        if (methodID === 'CREDIT_CARD') {
            $('#js_breadsummary').html(' ');
			$('.payment-details').show();
        }
    });

    if ($('.payment-information').data('payment-method-id') === 'PAYPLAN') {
        $('.order-summary-email').html(data.email.value);
        $('.order-summary-phone').html(data.phone.value);
    }
});
