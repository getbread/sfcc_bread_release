// initialize BreadService
let Resource = require('dw/web/Resource');
let serviceID = Resource.msg('tenant.service','tenant',null);

let initBreadService = require('dw/svc/LocalServiceRegistry').createService(serviceID, {
    createRequest: function (service, params) {
        service.setAuthentication('BASIC');
        // if get there is no body to send
        return params || '';
    },

    parseResponse: function (service, response) {
        return response;
    },

    getRequestLogMessage: function (data) {
        return data;
    },

    getResponseLogMessage: function (data) {
        let response = !empty(data.text) ? data.text : data;
        return response;
    }
});
module.exports = initBreadService;

