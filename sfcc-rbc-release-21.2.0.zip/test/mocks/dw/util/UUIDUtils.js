var UUIDUtils = function () {};

UUIDUtils.createUUID = function () {
    return 'checkoutId';
};

module.exports = UUIDUtils;
