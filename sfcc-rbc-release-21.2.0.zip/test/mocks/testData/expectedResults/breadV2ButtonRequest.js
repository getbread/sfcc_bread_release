module.exports = {
    buyer: '{"givenName":"Customer name","familyName":"Customer surname","email":"test@test.com","phone":"3333333333","billingAddress":{"address1":"1000 Ainsworth Dr","address2":"Customer address 2","country":"US","locality":"Prescott","region":"AZ","postalCode":"86305"},"shippingAddress":{"address1":"1000 Ainsworth Dr","address2":"","country":"US","locality":"Prescott","region":"AZ","postalCode":"86305"}}',
    order: '{"items":[{"name":"Navy Single Pleat Wool Suit","sku":"750518548296M","category":"","brand":"","currency":"USD","quantity":1,"unitPrice":1300,"unitTax":200,"shippingCost":0,"shippingDescription":""}],"currency":"USD","subTotal":12500,"totalTax":1550,"totalShipping":3000,"totalDiscounts":500,"totalPrice":32548}'
};
