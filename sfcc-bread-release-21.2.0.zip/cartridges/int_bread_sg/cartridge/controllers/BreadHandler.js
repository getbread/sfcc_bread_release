/**
* @module  controllers/BreadHandler
*/

'use strict';
/* Script Modules */
let guard = require('*/cartridge/scripts/guard');
let app = require('*/cartridge/scripts/app');
let URLUtils = require('dw/web/URLUtils');

/**
* Just redirect with csrf protection to avoid vulnerability
*
*/
let checkout = function () {
    response.redirect(URLUtils.https('COSummary-Submit'), 307);
};

/**
* Renders Bread button for product set details page
*
*/
let buttonPS = function () {
    let ProductMgr = require('dw/catalog/ProductMgr');
    let params = request.httpParameterMap;
    let pidsArray = JSON.parse(params.pids.stringValue);
    let setProducts = pidsArray.map(function (productID) {
        return ProductMgr.getProduct(productID);
    });
    let template = 'bread/buttonOnPdpV2';

    app.getView({
        isSet: true,
        ProductSetList: setProducts
    }).render(template);
};

exports.Checkout = guard.ensure(['https', 'post', 'csrf'], checkout);
exports.ButtonPS = guard.ensure(['https', 'get'], buttonPS);

