'use strict';

let server = require('server');

/* API includes */
let BasketMgr = require('dw/order/BasketMgr');
let URLUtils = require('dw/web/URLUtils');
let csrfProtection = require('*/cartridge/scripts/middleware/csrf');

server.extend(module.superModule);

/**
 *  Clear Bread payment instrument
 */
server.prepend(
    'SubmitPayment',
    server.middleware.https,
    csrfProtection.validateAjaxRequest,
    function (req, res, next) {
        let Transaction = require('dw/system/Transaction');
        let collections = require('*/cartridge/scripts/util/collections');

        let currentBasket = BasketMgr.getCurrentBasket();
        if (currentBasket) {
            Transaction.wrap(function () {
                let paymentInstruments = currentBasket.getPaymentInstruments('BREAD');
                collections.forEach(paymentInstruments, function (item) {
                    currentBasket.removePaymentInstrument(item);
                });
            });
        }
        return next();
    }
);

/* just to pass BREAD payment method through PlaceOrder controller */
server.prepend('PlaceOrder', function (req, res, next) {
    let paymentInstruments = BasketMgr.getCurrentBasket().getPaymentInstruments().iterator();

    while (paymentInstruments.hasNext()) {
        let paymentInsturment = paymentInstruments.next();
        if (paymentInsturment.paymentMethod === 'BREAD') {
            session.privacy.BREAD = 'BREAD';
            break;
        }
    }

    next();
});

/* redirect to native order confirmation page */
server.append('PlaceOrder', function (req, res, next) {
    let Resource = require('dw/web/Resource');
    let CartModel = require('*/cartridge/models/cart');
    let currentBasket;
    let basketModel;
    if (session.privacy && session.privacy.BREAD === 'BREAD') {
        session.privacy.BREAD = '';
        if (res.viewData.orderID) {
            if (!res.viewData.error) {
                let orderId = res.viewData.orderID;
                let orderToken = res.viewData.orderToken;
                res.setRedirectStatus(307);
                res.redirect(URLUtils.https('Order-Confirm', 'ID', orderId, 'token', orderToken).toString());
            } else {
                currentBasket = BasketMgr.getCurrentBasket();
                basketModel = new CartModel(currentBasket);
                basketModel.valid = {
                    error: true,
                    message: Resource.msg('error.technical', 'checkout', null)
                };
                res.render('cart/cart', basketModel);
                return next();
            }
        }
    }
    if (res.viewData.error) {
        currentBasket = BasketMgr.getCurrentBasket();
        basketModel = new CartModel(currentBasket);
        basketModel.valid = {
            error: true,
            message: Resource.msg('error.technical', 'checkout', null)
        };
        res.render('cart/cart', basketModel);
        return next();
    }
    return next();
});

module.exports = server.exports();
