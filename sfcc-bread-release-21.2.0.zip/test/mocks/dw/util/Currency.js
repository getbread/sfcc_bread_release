var Currency = function () {};

Currency.getCurrency = function () {};
Currency.prototype.getCurrencyCode = function () { return 'USD'; };
Currency.prototype.getSymbol = function () {};
Currency.prototype.getDefaultFractionDigits = function () {};
Currency.prototype.toString = function () {};
Currency.prototype.getName = function () {};
Currency.prototype.currency = null;
Currency.prototype.currencyCode = 'USD';
Currency.prototype.symbol = null;
Currency.prototype.defaultFractionDigits = null;
Currency.prototype.name = null;

module.exports = Currency;
