var Calendar = function (date) {
    this.time = date || '12/12/2019';
};

Calendar.prototype.getTimeZone = function () {};
Calendar.prototype.setTimeZone = function () {};
Calendar.prototype.add = function () {};
Calendar.prototype.get = function () {};
Calendar.prototype.equals = function () {};
Calendar.prototype.hashCode = function () {};
Calendar.prototype.compareTo = function () {};
Calendar.prototype.clear = function () {};
Calendar.prototype.isSet = function () {};
Calendar.prototype.set = function () {};
Calendar.prototype.after = function () {};
Calendar.prototype.before = function () {};
Calendar.prototype.getTime = function () {};
Calendar.prototype.setTime = function () {};
Calendar.prototype.getMinimum = function () {};
Calendar.prototype.getMaximum = function () {};
Calendar.prototype.getActualMinimum = function () {};
Calendar.prototype.getActualMaximum = function () {};
Calendar.prototype.isLeapYear = function () {};
Calendar.prototype.roll = function () {};
Calendar.prototype.getFirstDayOfWeek = function () {};
Calendar.prototype.setFirstDayOfWeek = function () {};
Calendar.prototype.parseByFormat = function () {};
Calendar.prototype.parseByLocale = function () {};
Calendar.prototype.isSameDay = function () {};
Calendar.prototype.timeZone = null;
Calendar.prototype.time = null;
Calendar.prototype.minimum = null;
Calendar.prototype.maximum = null;
Calendar.prototype.actualMinimum = null;
Calendar.prototype.actualMaximum = null;
Calendar.prototype.firstDayOfWeek = null;

module.exports = Calendar;
