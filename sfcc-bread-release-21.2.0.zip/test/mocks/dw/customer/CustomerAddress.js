
var CustomerAddress = function (addressObj) {
    if (addressObj) {
        this.countryCode = {
            value: addressObj.countryCode,
            displayValue: addressObj.countryCode
        };
        this.city = addressObj.city;
        this.postalCode = addressObj.postalCode;
        this.address1 = addressObj.address1,
        this.address2 = addressObj.address2,
        this.custom = addressObj.custom || {};
    } else {
        this.custom = {};
    }
};

CustomerAddress.prototype.getID = function () {};
CustomerAddress.prototype.getSuite = function () {};
CustomerAddress.prototype.getAddress1 = function () {};
CustomerAddress.prototype.getAddress2 = function () {};
CustomerAddress.prototype.getCity = function () {};
CustomerAddress.prototype.getStateCode = function () {};
CustomerAddress.prototype.getPostalCode = function () {};
CustomerAddress.prototype.getCountryCode = function () {};
CustomerAddress.prototype.getPhone = function () {};
CustomerAddress.prototype.getTitle = function () {};
CustomerAddress.prototype.setID = function (id) { this.ID = id; };
CustomerAddress.prototype.setCity = function () {};
CustomerAddress.prototype.getCompanyName = function () {};
CustomerAddress.prototype.setCompanyName = function () {};
CustomerAddress.prototype.setCountryCode = function () {};
CustomerAddress.prototype.getFirstName = function () {};
CustomerAddress.prototype.setFirstName = function () {};
CustomerAddress.prototype.getFullName = function () {};
CustomerAddress.prototype.getJobTitle = function () {};
CustomerAddress.prototype.setJobTitle = function () {};
CustomerAddress.prototype.getLastName = function () {};
CustomerAddress.prototype.setLastName = function () {};
CustomerAddress.prototype.setPhone = function () {};
CustomerAddress.prototype.setPostalCode = function () {};
CustomerAddress.prototype.getPostBox = function () {};
CustomerAddress.prototype.setPostBox = function () {};
CustomerAddress.prototype.getSecondName = function () {};
CustomerAddress.prototype.setSecondName = function () {};
CustomerAddress.prototype.setStateCode = function () {};
CustomerAddress.prototype.setAddress1 = function () {};
CustomerAddress.prototype.setAddress2 = function () {};
CustomerAddress.prototype.getSuffix = function () {};
CustomerAddress.prototype.setSuffix = function () {};
CustomerAddress.prototype.setTitle = function () {};
CustomerAddress.prototype.getSalutation = function () {};
CustomerAddress.prototype.setSaluation = function () {};
CustomerAddress.prototype.setSalutation = function () {};
CustomerAddress.prototype.setSuite = function () {};
CustomerAddress.prototype.isEquivalentAddress = function () {};
CustomerAddress.prototype.ID = null;
CustomerAddress.prototype.suite = null;
CustomerAddress.prototype.address1 = null;
CustomerAddress.prototype.address2 = null;
CustomerAddress.prototype.city = null;
CustomerAddress.prototype.stateCode = null;
CustomerAddress.prototype.postalCode = null;
CustomerAddress.prototype.countryCode = null;
CustomerAddress.prototype.phone = null;
CustomerAddress.prototype.title = null;
CustomerAddress.prototype.companyName = null;
CustomerAddress.prototype.firstName = null;
CustomerAddress.prototype.fullName = null;
CustomerAddress.prototype.jobTitle = null;
CustomerAddress.prototype.lastName = null;
CustomerAddress.prototype.postBox = null;
CustomerAddress.prototype.secondName = null;
CustomerAddress.prototype.suffix = null;
CustomerAddress.prototype.salutation = null;

module.exports = CustomerAddress;
