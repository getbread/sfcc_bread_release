'use strict';

var assert = require('chai').assert;
var request = require('request-promise');
var config = require('../it.config');

/**
 * function to generate default request
 * @param {URL} url - value to set to request
 * @returns {Object} - request
 */
function createRequest(url) {
    var cookieJar = request.jar();
    var myRequest = {
        url: config.baseUrl + url,
        method: 'GET',
        rejectUnauthorized: false,
        resolveWithFullResponse: true,
        jar: cookieJar,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    };
    return myRequest;
}

describe('Handle Bread Webhook endpoint', function () {
    this.timeout(50000);

    it('Should be success response status from Approve endpoint', function () {
        var myRequest = createRequest('/Test-Bread');
        return request(myRequest)
            .then(function (approveResponse) {
                assert.equal(approveResponse.statusCode, 200, 'Expected statusCode to be 200.');

                var bodyAsJson = JSON.parse(approveResponse.body);
                var responseApprove = {
                    action: 'Test-Bread',
                    locale: 'default',
                    queryString: ''
                };

                assert.deepEqual(bodyAsJson, responseApprove);
                return approveResponse;
            });
    });
});
