var StringUtils = function () {};

StringUtils.format = function () {};
StringUtils.trim = function () {};
StringUtils.truncate = function () {};
StringUtils.encodeBase64 = function (data) { return data; };
StringUtils.decodeBase64 = function (data) { return data; };
StringUtils.pad = function () {};
StringUtils.encodeString = function () {};
StringUtils.decodeString = function () {};
StringUtils.stringToHtml = function () {};
StringUtils.stringToXml = function () {};
StringUtils.stringToWml = function () {};
StringUtils.ltrim = function () {};
StringUtils.rtrim = function () {};
StringUtils.formatInteger = function () {};
StringUtils.formatNumber = function () {};
StringUtils.formatMoney = function () {};
StringUtils.formatDate = function () {};
StringUtils.formatCalendar = function (calendar) {
    return calendar.time;
};
StringUtils.garble = function () {};

module.exports = StringUtils;
