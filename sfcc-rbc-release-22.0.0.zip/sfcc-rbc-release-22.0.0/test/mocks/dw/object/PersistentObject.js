var PersistentObject = function () {};

PersistentObject.prototype.getLastModified = function () {};
PersistentObject.prototype.getCreationDate = function () {};
PersistentObject.prototype.__id = function () {};
PersistentObject.prototype.getUUID = function () { return this.UUID; };
PersistentObject.prototype.lastModified = null;
PersistentObject.prototype.creationDate = null;
PersistentObject.prototype.UUID = null;

module.exports = PersistentObject;
