// module for transactions with bread new service api
let Transaction = require('dw/system/Transaction');
let Order = require('dw/order/Order');
let CacheMgr = require('dw/system/CacheMgr');
let breadData = require('int_payplan/cartridge/scripts/lib/breadData.js');

let Calls = function () {
    let service = require('int_payplan/cartridge/scripts/service/breadInit.js');
    let apiUrl = breadData.getServerApiUrl();
    let authUrl = breadData.getAuthUrl();
    let that = this;
    // retrieve
    that.getTransaction = function (trId, order) {
        let getTokenResult = that.getToken();
        if (!getTokenResult.token) {
            return getTokenResult;
        }
        service.setRequestMethod('GET');
        service.setURL(apiUrl + '/api/transaction/' + trId);
        service.addHeader('Authorization', 'Bearer ' + getTokenResult.token);
        let response = service.call();
        let object = false;
        if (response.ok && !response.object.errorText) {
            try {
                object = JSON.parse(response.object.text);
                if (order && object.status) {
                    Transaction.wrap(function () {
                        order.custom.payplan_status = object.status; // eslint-disable-line no-param-reassign
                    });
                }
            } catch (e) {
                object = { error: true, status: e.message };
            }
        }
        return object;
    };

    // cancel, settle, refund and authorize
    that.actionTransaction = function (order, action, amountValue) {
        let getTokenResult = that.getToken();
        if (!getTokenResult.token) {
            return getTokenResult;
        }
        let param = {
            amount: {
                currency: order.currencyCode,
                value: Number(amountValue)
            }
        };
        service.setRequestMethod('POST');
        service.setURL(apiUrl + '/api/transaction/' + order.custom.payplan_token + '/' + action);
        service.addHeader('Content-Type', 'application/json');
        service.addHeader('Authorization', 'Bearer ' + getTokenResult.token);

        let response = service.call(JSON.stringify(param));
        let object = false;
        if (response.ok) {
            // try catch error
            try {
                object = JSON.parse(response.object.text);
                Transaction.wrap(function () {
                    if ('status' in object) {
                        order.custom.payplan_status = object.status; // eslint-disable-line no-param-reassign
                    }
                    if (action === 'authorize') {
                        order.setPaymentStatus(Order.PAYMENT_STATUS_PAID);
                    }
                });
            } catch (e) {
                object = { error: true, msg: e.message };
            }
        } else {
            object = { error: true, msg: response.errorMessage, param: JSON.stringify(param) };
        }
        // if settle is enabled in site preferences we call transaction again with settle param
        if (action === 'authorize' && breadData.isSettleEnabled()) {
            return that.actionTransaction(order, 'settle', amountValue);
        }
        return object;
    };

    // update shipping info
    that.updateShipping = function (order, shippingRequest) {
        let getTokenResult = that.getToken();
        if (!getTokenResult.token) {
            return getTokenResult;
        }
        service.setRequestMethod('POST');
        service.setURL(apiUrl + '/api/transaction/' + order.custom.payplan_token + '/fulfillment');
        service.addHeader('Content-Type', 'application/json');
        service.addHeader('Authorization', 'Bearer ' + getTokenResult.token);

        let response = service.call(JSON.stringify(shippingRequest));
        let object = {};
        if (response.ok) {
            // try catch error
            try {
                object = JSON.parse(response.object.text);
            } catch (e) {
                object = { error: true, msg: e.message };
            }
        } else {
            object = { error: true, msg: response.errorMessage, request: JSON.stringify(shippingRequest) };
        }
        return object;
    };

    // update order number
    that.updateOrderNumber = function (order) {
        let getTokenResult = that.getToken();
        if (!getTokenResult.token) {
            return getTokenResult;
        }
        service.setRequestMethod('PATCH');
        service.setURL(apiUrl + '/api/transaction/' + order.custom.payplan_token);
        service.addHeader('Content-Type', 'application/json');
        service.addHeader('Authorization', 'Bearer ' + getTokenResult.token);

        let response = service.call(JSON.stringify({
            externalID: order.orderNo,
        }));
        let object = {};
        if (response.ok) {
            // try catch error
            try {
                object = JSON.parse(response.object.text);
            } catch (e) {
                object = { error: true, msg: e.message };
            }
        } else {
            object = { error: true, msg: response.errorMessage, request: JSON.stringify(shippingRequest) };
        }
        return object;
    };

    that.merchantInfo = function () {
        let cache = CacheMgr.getCache('payplanCache');
        let integrationKey = breadData.getIntegrationKey();
        let data = cache.get(integrationKey);
        if (data) {
            return data;
        }

        let getTokenResult = that.getToken();
        if (!getTokenResult.token) {
            return getTokenResult;
        }
        service.setRequestMethod('GET');
        service.setURL(apiUrl + '/api/experience-keys/' + integrationKey);
        service.addHeader('Content-Type', 'application/json');

        let response = service.call();
        let object = false;
        if (response.ok && !response.object.errorText) {
            try {
                object = JSON.parse(response.object.text);
                cache.put(integrationKey, object);
                return object;
            } catch (e) {
                object = { error: true, status: e.message };
            }
        }
        return object;
    };

    that.asLowAs = function (amount) {
        amount = Math.round(amount * 100);
        let cache = CacheMgr.getCache('payplanCache');
        let data = cache.get(amount);
        if (data) {
            return JSON.stringify(data);
        }

        let getTokenResult = that.getToken();
        if (!getTokenResult.token) {
            return getTokenResult;
        }

        let merchantInfo = that.merchantInfo();
        service.setRequestMethod('GET');
        service.setURL(apiUrl + '/api/experience/servicing/as-low-as?merchantId=' + merchantInfo.merchantID + "&programId=" + merchantInfo.programID + "&amount=" + amount);
        service.addHeader('Content-Type', 'application/json');

        let response = service.call();
        let object = false;
        if (response.ok && !response.object.errorText) {
            try {
                object = JSON.parse(response.object.text);
                cache.put(amount, object);
                return JSON.stringify(object);
            } catch (e) {
                object = { error: true, status: e.message };
            }
        }
        return object;
    };

    that.getToken = function () {
        if (session.privacy.apiToken && session.privacy.tokenExpiresAt) {
            if (Date.parse(session.privacy.tokenExpiresAt) - Date.now() > 0) {
                return { token: session.privacy.apiToken };
            }
        }
        service.setRequestMethod('POST');
        service.setURL(authUrl);
        service.addHeader('Content-Type', 'application/json');
        let param = {
            apiKey: breadData.getApiKey(),
            secret: breadData.getApiSecret(),
        };
        let response = service.call(JSON.stringify(param));
        let object;
        if (response.ok) {
            try {
                object = JSON.parse(response.object.text);
                if (object.token && object.tokenExpiresAt) {
                    session.privacy.apiToken = object.token;
                    session.privacy.tokenExpiresAt = object.tokenExpiresAt.replace(/\.(.*?)Z/, '');
                }
            } catch (e) {
                object = { error: true, msg: e.message };
            }
        } else {
            object = { error: true, msg: response.errorMessage };
        }
        return object;
    };
};

module.exports = new Calls();
