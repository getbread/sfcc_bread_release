'use strict';

let Status = require('dw/system/Status');
let logger = require('dw/system').Logger.getLogger('Bread', '');

/**
 * @returns {dw.system.Status} result status
 */
function execute() {
    let breadJobs = require('int_payplan/cartridge/scripts/bread');
    try {
        breadJobs.cancelOrders();
        breadJobs.settleOrders();
        breadJobs.refundOrders();
        breadJobs.addShippingInfo();
        return new Status(Status.OK);
    } catch (e) {
        logger.error(e)
        return new Status(Status.ERROR);
    }
}

exports.execute = execute;